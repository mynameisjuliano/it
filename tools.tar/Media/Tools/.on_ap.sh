#!/bin/sh

am start -n 'com.android.settings/.Settings$WifiTetherSettingsActivity'
sleep 0.5s
input keyevent TAB; sleep 0.5s;
input keyevent ENTER; sleep 0.5s;
