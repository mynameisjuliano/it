tts-speak "Messages:"
termux-notification-list | jq -r '.[] | select(.packageName == "com.android.messaging") | .title, .content' | xargs tts-speak
