#!/bin/sh

PID=$$
start_record() {
	if [ "$(termux-microphone-record -i | jq -r .isRecording)" = "true" ]; then
		termux-microphone-record -q
		tts-speak "Recording saved..."
	else
		tts-speak "Starting recording in ..."
		for i in $(seq 1 20 | sort -rn); do
			tts-speak "$i"
			sleep 1s
		done

		termux-microphone-record -f "$HOME/Media/:Records/$(date +"%F %T" | tr ":" "-").wav" \
			-l 14400 -c 2
	fi
}

start_record &
