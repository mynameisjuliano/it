#!/bin/sh
sleep 1s
tts-speak zero-9-6-5
sleep 1s
tts-speak 5-04
sleep 1s
tts-speak 3-3-1-2
sleep 2s
