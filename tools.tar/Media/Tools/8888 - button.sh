
tts-speak "alt-menu, shortpress"
sleep 0.2s
tts-speak "up: loop toogle"
sleep 0.2s
tts-speak "down: save-on-quit toogle"

sleep 0.5s
tts-speak "alt-menu, long press"
sleep 0.2s
tts-speak "up: bookmark"
sleep 0.2s
tts-speak "down: info"
sleep 0.5s
tts-speak "rest is attemped intuiatively"
