#!/bin/sh

pgrep -f "3 - record_delayed.sh" | xargs kill && tts-speak "Recording cancelled."
