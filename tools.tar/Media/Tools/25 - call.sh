#!/bin/sh

tts-speak "Speak number to call"
# tts-speak "no no. aborts."
CALLNO="$(termux-speech-to-text | sed "s/[^0-9]//g")"
if [ -n  "$CALLNO" ]; then
	tts-speak "Calling $CALLNO"
	sleep 2s
	mpv "$HOME/dmp/audio/audio.ogg"
	termux-telephony-call "$CALLNO"
else
	tts-speak "Cancelling..."
fi
