#!/bin/sh

# this uses the service "start_input"
# which reads input from /data/[user]/com.termux/files/.root_input
# to be executed on a shell, with root access.
# be careful! (rm's and mv's are disabled by default)

R_S_PATH=/data/data/com.termux/files/.root_input

# to avoid race conditions, only send batches of commands
# so we have to wait concurrently of the execution
# then ask for the result...

echo """
am start -n 'com.android.settings/.Settings\$BluetoothSettingsActivity'
sleep 1s
input tap 300 1300
sleep 3s;
input keyevent BACK; sleep 0.5s;
input keyevent HOME; sleep 0.5s;
""" > "$R_S_PATH"

sleep 3s;

tts-speak "Trying to connect to Lenovo LP40"
