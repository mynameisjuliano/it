tts-speak "Messenger:"
termux-notification-list | jq -r '.[] | select(.packageName == "com.facebook.orca") | .title, .content' | xargs tts-speak
