# tts-speak "IP's"
ifconfig 2>/dev/null | grep -o "inet\s*[0-9.]*" | cut -f2 -d" "  | sed "/127.0.0.1/d; s/\./ (dot) /g; s/^/IP: /; s/$/:......../"  | xargs tts-speak
