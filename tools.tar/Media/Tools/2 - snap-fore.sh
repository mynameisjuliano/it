#!/bin/sh

termux-camera-photo -c 1 "/sdcard/Pictures/term/$(date +"%F-%T" | tr ":" "-").jpeg"
mpv "$HOME/dmp/audio/camera_click.ogg" 2>&1 > /dev/null
